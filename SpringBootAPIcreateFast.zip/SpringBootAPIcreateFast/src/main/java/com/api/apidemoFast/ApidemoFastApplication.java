package com.api.apidemoFast;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApidemoFastApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApidemoFastApplication.class, args);
	}

}
