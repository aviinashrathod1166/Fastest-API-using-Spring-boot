package com.api.apidemoFast.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.api.apidemoFast.entity.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {

}
