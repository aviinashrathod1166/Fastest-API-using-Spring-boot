package com.api.apidemoFast.services;

import java.util.List;

import com.api.apidemoFast.entity.Product;

public interface ProductService {

	Product create(Product product);

	Product update(Product product, int productId);

	void delete(int productId);

	Product getById(int productId);

	List<Product> getAll();

}
